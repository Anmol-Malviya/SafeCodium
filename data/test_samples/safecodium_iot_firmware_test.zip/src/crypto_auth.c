#include <stdio.h>
#include <string.h>

// Simulated BLE handshake token parser with Buffer Overflow (CWE-120)
int verify_ble_peer_token(const char *inbound_token) {
    char local_token[32];

    // VULNERABILITY: sprintf unbounded copy into 32-byte stack buffer
    // SAFE-CODIUM should replace with snprintf(local_token, sizeof(local_token), ...)
    sprintf(local_token, "%s", inbound_token);

    if (strcmp(local_token, "SECURE_BLE_AES_2026") == 0) {
        return 1;
    }
    return 0;
}
