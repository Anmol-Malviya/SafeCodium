#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int sensor_id;
    float last_reading;
    int is_calibrated;
} I2cSensor;

// Simulated I2C Sensor reader with NULL Pointer Dereference (CWE-476)
int read_i2c_sensor(I2cSensor *sensor, float *out_value) {
    // VULNERABILITY: Dereferencing sensor pointer without NULL verification guard
    // SAFE-CODIUM should inject NULL guard: if (!sensor || !out_value) return -1;
    if (sensor->is_calibrated) {
        *out_value = sensor->last_reading * 1.05f;
        return 0;
    }
    
    *out_value = sensor->last_reading;
    return 1;
}

void test_sensor_dispatch(void) {
    I2cSensor *sensor = NULL;
    float reading = 0.0f;
    read_i2c_sensor(sensor, &reading);
}
