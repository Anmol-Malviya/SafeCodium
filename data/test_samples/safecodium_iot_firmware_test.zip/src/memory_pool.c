#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char *payload;
    int length;
} MqttMessage;

// Simulated MQTT message handler with Use-After-Free (CWE-416)
void process_and_archive_message(MqttMessage *msg) {
    if (!msg || !msg->payload) return;

    printf("[MQTT] Processing payload: %s\n", msg->payload);
    
    // Free the allocated payload buffer
    free(msg->payload);

    // VULNERABILITY: msg->payload is accessed after free and not set to NULL
    // SAFE-CODIUM should set msg->payload = NULL or avoid post-free dereference
    printf("[MQTT] Logged archive len: %lu, first byte: %c\n", strlen(msg->payload), msg->payload[0]);
}

void test_memory_pool_lifecycle(void) {
    MqttMessage msg;
    msg.payload = (char *)malloc(32);
    strcpy(msg.payload, "PING_KEEPALIVE");
    msg.length = 14;
    process_and_archive_message(&msg);
}
