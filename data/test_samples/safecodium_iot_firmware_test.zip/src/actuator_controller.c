#include <stdio.h>

#define MAX_PRESETS 8
static int pwm_preset_table[MAX_PRESETS] = { 10, 25, 50, 75, 100, 125, 150, 200 };

// Simulated Actuator control with Out-of-bounds Write (CWE-787)
int update_motor_pwm_profile(int profile_index, int new_pwm_val) {
    // VULNERABILITY: Missing upper-bound check on array index (CWE-787)
    // SAFE-CODIUM should enforce: if (profile_index < 0 || profile_index >= MAX_PRESETS) return -1;
    pwm_preset_table[profile_index] = new_pwm_val;
    
    return pwm_preset_table[profile_index];
}

void test_actuator_bounds(void) {
    update_motor_pwm_profile(12, 255); // Overwrite adjacent memory
}
