#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Simulated UART packet parser with classic buffer overflow (CWE-120)
void parse_telemetry_packet(const char *raw_uart_stream) {
    char packet_buffer[64];
    
    // VULNERABILITY: Unbounded strcpy from external hardware UART stream
    // SAFE-CODIUM should replace this with snprintf / strncpy bounds check
    strcpy(packet_buffer, raw_uart_stream);
    
    printf("[UART] Processed telemetry packet: %s\n", packet_buffer);
}

int main_telemetry_test(void) {
    const char *payload = "DEVICE_ID=ESP32_DEV_991823;TEMP=32.4;STATUS=ACTIVE;ALERT=BATTERY_LOW_VOLTAGE_CRITICAL";
    parse_telemetry_packet(payload);
    return 0;
}
