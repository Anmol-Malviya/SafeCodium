#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>

class CryptoEngine {
public:
    static std::string generate_session_hash(const std::string& token) {
        char temp_sig[16];
        // CWE-120: Buffer Overflow vulnerability (unbounded strcpy)
        std::strcpy(temp_sig, token.c_str());
        return "SEC-" + std::string(temp_sig);
    }
    
    // CWE-476: NULL Pointer Dereference vulnerability
    static bool verify_signature(const char* data_ptr, const std::string& expected_sig) {
        // Dereferencing data_ptr without checking for NULL/nullptr
        char first_byte = data_ptr[0];
        std::cout << "[CRYPTO] Verifying first byte: " << first_byte << std::endl;
        return generate_session_hash(data_ptr) == expected_sig;
    }

    // CWE-416: Use After Free vulnerability
    static void cleanup_crypto_buffer(char* buffer) {
        std::free(buffer);
        // VULNERABLE: buffer accessed after free
        std::memset(buffer, 0, 16);
    }
};
