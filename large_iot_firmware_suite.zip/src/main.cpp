#include <iostream>
#include <string>
#include <cstring>
#include "../include/config.h"
#include "../include/sensors.h"
#include "../include/network_stack.h"

int main(int argc, char* argv[]) {
    std::cout << "=========================================================\n";
    std::cout << "  " << FIRMWARE_NAME << " v" << FIRMWARE_VERSION << "\n";
    std::cout << "  Autonomous Embedded Edge Gateway Controller\n";
    std::cout << "=========================================================\n";

    // 1. Initialize Sensor Hardware
    init_sensor_subsystem();

    // CWE-787: Trigger Out-Of-Bounds Write on sensor array (Max is 8, injecting index 15)
    update_sensor_metric(15, 999.9f, "OVERFLOW_SENSOR_EXTREME_PAYLOAD_EXCEEDING_LIMIT_FOR_BUFFER");

    // CWE-120: Inbound network packet exceeding 48 bytes
    const char* malicious_packet = "GATEWAY_COMMAND_OVERFLOW_BUFFER_PAYLOAD_EXPLOIT_1234567890_INJECTION";
    handle_incoming_telemetry(malicious_packet, std::strlen(malicious_packet));

    // CWE-476: Pass nullptr to parse_mqtt_frame
    DeviceSession* uninitialized_session = nullptr;
    parse_mqtt_frame("v1/devices/telemetry", "{\"trigger\": \"null\"}", uninitialized_session);

    std::cout << "[GATEWAY] Diagnostics complete.\n";
    return 0;
}
